import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
const firebaseConfig = {
  apiKey: "AIzaSyDRkpi3xxtSRXX4eViowmw3mgrS3NIoU2I",
  authDomain: "uas-pti-kelompok3.firebaseapp.com",
  projectId: "uas-pti-kelompok3",
  storageBucket: "uas-pti-kelompok3.appspot.com",
  messagingSenderId: "371607974036",
  appId: "1:371607974036:web:779d9829a6eb1818ab8481",
  measurementId: "G-HENHCLH2XP"
};
const firebaseApp = initializeApp(firebaseConfig);
getAuth(firebaseApp);
new GoogleAuthProvider();
