import { c as create_ssr_component, s as subscribe, v as validate_component } from "./app-724b3805.js";
import { i as isLoggedIn } from "./auth-4f44352c.js";
import "./firebase-a0ca69cc.js";
import "@sveltejs/kit/ssr";
import "cookie";
import "@lukeed/uuid";
import "./index-c35ae2d2.js";
import "firebase/app";
import "firebase/auth";
const Nav = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $isLoggedIn, $$unsubscribe_isLoggedIn;
  $$unsubscribe_isLoggedIn = subscribe(isLoggedIn, (value) => $isLoggedIn = value);
  $$unsubscribe_isLoggedIn();
  return `<nav class="${"navbar navbar-expand-lg navbar-dark bg-dark text-white "}"><a class="${"navbar-brand"}" href="${"/"}">Kelompok 3</a>
	<button class="${"navbar-toggler"}" type="${"button"}" data-toggle="${"collapse"}" data-target="${"#navbarNavAltMarkup"}" aria-controls="${"navbarNavAltMarkup"}" aria-expanded="${"false"}" aria-label="${"Toggle navigation"}"><span class="${"navbar-toggler-icon"}"></span></button>
	<div class="${"collapse navbar-collapse"}" id="${"navbarNavAltMarkup"}"><div class="${"navbar-nav"}"><a class="${"nav-link active"}" href="${"/"}">News <span class="${"sr-only"}">(current)</span></a>
			<a class="${"nav-link active"}" href="${"/blog"}">Blogs</a>
			<a class="${"nav-link active"}" href="${"/aboutUs"}">Developers</a></div>
		${$isLoggedIn ? `<ul class="${"nav navbar-nav ml-auto active"}"><a class="${"nav-link active"}" href="${"/login"}">Logout</a></ul>` : ``}</div></nav>`;
});
const _layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(Nav, "Nav").$$render($$result, {}, {}, {})}

${slots.default ? slots.default({}) : ``}`;
});
export { _layout as default };
