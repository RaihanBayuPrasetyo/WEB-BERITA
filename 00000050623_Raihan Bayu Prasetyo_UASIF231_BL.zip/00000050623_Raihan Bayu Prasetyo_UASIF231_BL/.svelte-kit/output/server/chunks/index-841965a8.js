import { c as create_ssr_component, s as subscribe, b as each, v as validate_component } from "./app-724b3805.js";
import { w as writable } from "./index-c35ae2d2.js";
import { C as Card } from "./card-40d05963.js";
import "@sveltejs/kit/ssr";
import "cookie";
import "@lukeed/uuid";
const news = writable([]);
const fetchNews = async () => {
  const url = `https://saurav.tech/NewsAPI/top-headlines/category/general/us.json`;
  const res = await fetch(url);
  const data = await res.json();
  const loadedNews = data.articles.map((data2) => {
    return {
      title: data2.title,
      description: data2.description,
      image: data2.urlToImage,
      homeUrl: data2.url
    };
  });
  news.set(loadedNews);
};
fetchNews();
const Routes = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $news, $$unsubscribe_news;
  $$unsubscribe_news = subscribe(news, (value) => $news = value);
  $$unsubscribe_news();
  return `${$$result.head += `${$$result.title = `<title>News API</title>`, ""}`, ""}

${each($news, (berita) => `${validate_component(Card, "Card").$$render($$result, { card: berita }, {}, {})}`)}`;
});
export { Routes as default };
