import { c as create_ssr_component, s as subscribe, b as each, v as validate_component } from "./app-724b3805.js";
import { w as writable } from "./index-c35ae2d2.js";
import { C as Card } from "./card-40d05963.js";
import { i as isLoggedIn } from "./auth-4f44352c.js";
import "@sveltejs/kit/ssr";
import "cookie";
import "@lukeed/uuid";
function guard(name) {
  return () => {
    throw new Error(`Cannot call ${name}(...) on the server`);
  };
}
const goto = guard("goto");
const blogs = writable([]);
const fetchBlogs = async () => {
  const url = `https://saurav.tech/NewsAPI/everything/cnn.json`;
  const res = await fetch(url);
  const data = await res.json();
  const loadedBlogs = data.articles.map((data2) => {
    return {
      title: data2.title,
      description: data2.description,
      image: data2.urlToImage,
      homeUrl: data2.url
    };
  });
  blogs.set(loadedBlogs);
};
fetchBlogs();
const Blog = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $isLoggedIn, $$unsubscribe_isLoggedIn;
  let $blogs, $$unsubscribe_blogs;
  $$unsubscribe_isLoggedIn = subscribe(isLoggedIn, (value) => $isLoggedIn = value);
  $$unsubscribe_blogs = subscribe(blogs, (value) => $blogs = value);
  if (!$isLoggedIn) {
    goto("/login");
  }
  $$unsubscribe_isLoggedIn();
  $$unsubscribe_blogs();
  return `${$$result.head += `${$$result.title = `<title>Blogs</title>`, ""}`, ""}

${$isLoggedIn ? `${each($blogs, (berita) => `${validate_component(Card, "Card").$$render($$result, { card: berita }, {}, {})}`)}` : ``}`;
});
export { Blog as default };
