import { w as writable } from "./index-c35ae2d2.js";
const user = writable({});
const isLoggedIn = writable(false);
export { isLoggedIn as i, user as u };
