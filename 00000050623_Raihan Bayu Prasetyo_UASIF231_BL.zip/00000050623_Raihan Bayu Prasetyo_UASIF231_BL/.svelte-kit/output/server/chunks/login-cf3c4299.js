import { c as create_ssr_component, s as subscribe } from "./app-724b3805.js";
import "./firebase-a0ca69cc.js";
import { i as isLoggedIn, u as user } from "./auth-4f44352c.js";
import "firebase/auth";
import "@sveltejs/kit/ssr";
import "cookie";
import "@lukeed/uuid";
import "firebase/app";
import "./index-c35ae2d2.js";
const Login = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe_isLoggedIn;
  let $$unsubscribe_user;
  $$unsubscribe_isLoggedIn = subscribe(isLoggedIn, (value) => value);
  $$unsubscribe_user = subscribe(user, (value) => value);
  $$unsubscribe_isLoggedIn();
  $$unsubscribe_user();
  return `<div class="${"container"}"><div class="${"row mt-5"}"><div class="${"col d-flex justify-content-center"}"><h3 class="${"mt-3"}">Login With Google</h3></div></div>
	<div class="${"row mt-5"}"><div class="${"col text-center"}"><button class="${"btn btn-primary"}">Login</button></div></div></div>`;
});
export { Login as default };
