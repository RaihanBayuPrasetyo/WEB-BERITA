import { c as create_ssr_component, d as add_attribute, e as escape } from "./app-724b3805.js";
const Card = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { card } = $$props;
  if ($$props.card === void 0 && $$bindings.card && card !== void 0)
    $$bindings.card(card);
  return `<div class="${"mt-5"}"><div class="${"d-flex justify-content-center mb-4 mt-5 pl-5 pr-5"}"><div class="${"card "}" style="${"width: 50rem;"}"><img${add_attribute("src", card.image, 0)} class="${"card-img-top"}" alt="${"..."}">
			<div class="${"card-body"}"><h5 class="${"text-center"}">${escape(card.title)}</h5>
				<p class="${"card-text text-center"}">${escape(card.description)}</p>
				<div class="${"d-flex justify-content-center"}"><a${add_attribute("href", `${card.homeUrl}`, 0)} class="${"btn btn-light"}" target="${"_blank"}">Read More</a></div></div></div></div></div>`;
});
export { Card as C };
