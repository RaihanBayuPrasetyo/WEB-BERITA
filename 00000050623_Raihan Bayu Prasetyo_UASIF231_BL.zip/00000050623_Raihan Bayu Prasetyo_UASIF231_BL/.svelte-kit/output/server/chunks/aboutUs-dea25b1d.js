import { c as create_ssr_component } from "./app-724b3805.js";
import "@sveltejs/kit/ssr";
import "cookie";
import "@lukeed/uuid";
var aboutUs_svelte_svelte_type_style_lang = "";
const css = {
  code: ".card.svelte-1qumo0f.svelte-1qumo0f{box-shadow:0 0 20px 7px rgba(0, 0, 0, 0.1)}.card.svelte-1qumo0f.svelte-1qumo0f{margin:20px 10px;height:54vh}.card-body.svelte-1qumo0f.svelte-1qumo0f{text-align:center}.card-img-top.svelte-1qumo0f.svelte-1qumo0f{width:100%;height:30vh;object-fit:cover}.inner.svelte-1qumo0f.svelte-1qumo0f{overflow:hidden}.inner.svelte-1qumo0f img.svelte-1qumo0f{transition:all 1.2s ease}.inner.svelte-1qumo0f:hover img.svelte-1qumo0f{transform:scale(1.3)}i.svelte-1qumo0f.svelte-1qumo0f{margin-bottom:15px}",
  map: null
};
const AboutUs = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `${$$result.head += `${$$result.title = `<title>Developer</title>`, ""}`, ""}

<div class="${"container mt-5"}" id="${"developer"}"><h2 class="${"text-center mb-4"}">Our Developers</h2>
	<div class="${"row"}"><div class="${"col-md-3"}"><div class="${"card mt-3 svelte-1qumo0f"}"><div class="${"inner svelte-1qumo0f"}"><img src="${"/rio.jpg"}" class="${"card-img-top svelte-1qumo0f"}" alt="${"..."}"></div>
				<div class="${"card-body svelte-1qumo0f"}"><h5 class="${"card-title"}">Rio Febrian</h5>
					<p class="${"card-text"}">&quot;Be yourself and never surrender&quot;</p>
					<a href="${"https://www.instagram.com/riiofeb/"}" target="${"_blank"}"><i class="${"fab fa-instagram fa-2x svelte-1qumo0f"}"></i></a></div>
				<div class="${"card-footer text-muted text-center"}">00000048251</div></div></div>
		<div class="${"col-md-3"}"><div class="${"card mt-3 svelte-1qumo0f"}"><div class="${"inner svelte-1qumo0f"}"><img src="${"/bepe.jpg"}" class="${"card-img-top svelte-1qumo0f"}" alt="${"..."}"></div>
				<div class="${"card-body svelte-1qumo0f"}"><h5 class="${"card-title"}">Raihan Bayu</h5>
					<p class="${"card-text"}">&quot;Nothing lasts forever, we can change the future&quot;</p>
					<a href="${"https://www.instagram.com/raihanbepe/"}" target="${"_blank"}"><i class="${"fab fa-instagram fa-2x svelte-1qumo0f"}"></i></a></div>
				<div class="${"card-footer text-muted text-center"}">00000050623</div></div></div>
		<div class="${"col-md-3"}"><div class="${"card mt-3 svelte-1qumo0f"}"><div class="${"inner svelte-1qumo0f"}"><img src="${"/leo.jpg"}" class="${"card-img-top svelte-1qumo0f"}" alt="${"..."}"></div>
				<div class="${"card-body svelte-1qumo0f"}"><h5 class="${"card-title"}">Leo Candra</h5>
					<p class="${"card-text"}">&quot;Let me show you the art of killing! &quot;</p>
					<a href="${"https://www.instagram.com/leocand_/"}" target="${"_blank"}"><i class="${"fab fa-instagram fa-2x svelte-1qumo0f"}"></i></a></div>
				<div class="${"card-footer text-muted text-center"}">00000044308</div></div></div>
		<div class="${"col-md-3"}"><div class="${"card mt-3 svelte-1qumo0f"}"><div class="${"inner svelte-1qumo0f"}"><img src="${"/petra.jpg"}" class="${"card-img-top svelte-1qumo0f"}" alt="${"..."}"></div>
				<div class="${"card-body svelte-1qumo0f"}"><h5 class="${"card-title"}">Arnoldus Yitzhak Petra Manoppo</h5>
					<p class="${"card-text"}">&quot;Ga maen ml&quot;</p>
					<a href="${"https://www.instagram.com/petra167_/"}" target="${"_blank"}"><i class="${"fab fa-instagram fa-2x svelte-1qumo0f"}"></i></a></div>
				<div class="${"card-footer text-muted text-center"}">00000048162</div></div></div></div>
</div>`;
});
export { AboutUs as default };
