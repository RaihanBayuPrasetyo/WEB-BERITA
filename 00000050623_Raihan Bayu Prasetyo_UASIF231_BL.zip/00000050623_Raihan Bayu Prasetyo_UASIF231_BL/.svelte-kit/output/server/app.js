import "@sveltejs/kit/ssr";
export { i as init, r as render } from "./chunks/app-724b3805.js";
import "cookie";
import "@lukeed/uuid";
