let i;function r(t){i=t}export{r as i,i as r};
