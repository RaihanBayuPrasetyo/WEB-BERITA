import{C as s}from"./vendor-adf8e12d.js";const o=s({}),a=s(!1);export{a as i,o as u};
