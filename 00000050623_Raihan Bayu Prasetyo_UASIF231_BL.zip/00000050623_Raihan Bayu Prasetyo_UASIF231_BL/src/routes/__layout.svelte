<script>
	import Nav from '../components/nav.svelte';
</script>

<Nav />

<slot />
